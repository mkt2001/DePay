# DemoPay (offline simulation)

This project is a payment-flow UI prototype. It does not connect to a bank, UPI network,
or payment gateway, and it cannot confirm or prove a real payment. Demo receipts remain
visibly marked as DEMO.

## QR scanning
- Uses CameraX + ML Kit QR scanning.
- Reads payee name (pn), UPI ID (pa), amount (am), and note (tn) from standard
  `upi://pay` QR payloads when those fields are present.
- QR fields are displayed as scanned; missing fields are not invented.
- Scanning opens the local demo payment flow only. It does not send money.

Run `bash setup.sh` from this directory to arrange the source files and generate the
Android Gradle project structure.
