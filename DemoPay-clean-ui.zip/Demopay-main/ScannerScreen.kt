package com.demopay.app

import android.annotation.SuppressLint
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.ui.viewinterop.AndroidView
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private class QrAnalyzer(
    private val scanner: BarcodeScanner,
    private val onResult: (String) -> Unit
) : ImageAnalysis.Analyzer {
    private val completed = AtomicBoolean(false)
    private val processing = AtomicBoolean(false)

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(proxy: ImageProxy) {
        val mediaImage = proxy.image
        if (mediaImage == null || completed.get() || !processing.compareAndSet(false, true)) {
            proxy.close()
            return
        }
        try {
            val input = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
            scanner.process(input)
                .addOnSuccessListener { codes ->
                    val value = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                    if (value != null && completed.compareAndSet(false, true)) onResult(value)
                }
                .addOnCompleteListener {
                    processing.set(false)
                    proxy.close()
                }
        } catch (_: Exception) {
            processing.set(false)
            proxy.close()
        }
    }
}

@Composable
fun ScannerScreen(onResult: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = ctx as ComponentActivity
    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    var activeCamera by remember { mutableStateOf<Camera?>(null) }
    var torchOn by remember { mutableStateOf(false) }
    var scannerReady by remember { mutableStateOf(false) }
    val options = remember {
        BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    }
    val barcodeScanner = remember { BarcodeScanning.getClient(options) }

    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val image = InputImage.fromFilePath(ctx, uri)
            barcodeScanner.process(image)
                .addOnSuccessListener { codes ->
                    val value = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                    if (value != null) onResult(value)
                    else Toast.makeText(ctx, "No QR code found in this image", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { error ->
                    Toast.makeText(ctx, "Could not read image: ${error.localizedMessage ?: "try another image"}", Toast.LENGTH_LONG).show()
                }
        } catch (e: Exception) {
            Toast.makeText(ctx, "Unable to open selected image", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        val executor = Executors.newSingleThreadExecutor()
        val analyzer = QrAnalyzer(barcodeScanner) { text -> previewView.post { onResult(text) } }
        var provider: ProcessCameraProvider? = null

        future.addListener({
            try {
                val cameraProvider = future.get()
                provider = cameraProvider
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(executor, analyzer) }
                cameraProvider.unbindAll()
                activeCamera = cameraProvider.bindToLifecycle(
                    owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                scannerReady = true
            } catch (e: Exception) {
                previewView.post {
                    Toast.makeText(ctx, "Camera could not start: ${e.localizedMessage ?: "unknown error"}", Toast.LENGTH_LONG).show()
                }
            }
        }, ContextCompat.getMainExecutor(ctx))

        onDispose {
            try { activeCamera?.cameraControl?.enableTorch(false) } catch (_: Exception) { }
            provider?.unbindAll()
            barcodeScanner.close()
            executor.shutdown()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Box(
            Modifier.align(Alignment.Center).size(260.dp)
                .border(3.dp, Color.White, RoundedCornerShape(24.dp))
        )
        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(8.dp)
        ) {
            Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White)
        }

        Column(
            Modifier.align(Alignment.BottomCenter).padding(start = 20.dp, end = 20.dp, bottom = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Point the camera at a UPI QR code", color = Color.White, textAlign = TextAlign.Center)
            Text(
                "Or choose a QR image from your gallery. Details are decoded from the QR only; Demo mode, no money is transferred.",
                color = Color.White.copy(alpha = 0.82f), textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        val camera = activeCamera
                        if (camera == null || !camera.cameraInfo.hasFlashUnit()) {
                            Toast.makeText(ctx, "Torch is not available on this camera", Toast.LENGTH_SHORT).show()
                        } else {
                            val next = !torchOn
                            camera.cameraControl.enableTorch(next)
                                .addListener({ torchOn = next }, ContextCompat.getMainExecutor(ctx))
                        }
                    },
                    enabled = scannerReady,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30343B))
                ) {
                    Icon(if (torchOn) Icons.Filled.FlashOff else Icons.Filled.FlashOn, contentDescription = "Torch")
                    Text(if (torchOn) "Torch off" else "Torch", modifier = Modifier.padding(start = 6.dp))
                }
                Button(
                    onClick = { galleryPicker.launch("image/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF30343B))
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = "Gallery")
                    Text("Gallery", modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
    }
}
