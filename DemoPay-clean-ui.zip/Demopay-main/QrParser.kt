package com.demopay.app

import android.net.Uri
import java.math.BigDecimal
import java.math.RoundingMode

private const val MAX_QR_LEN = 600

private fun clean(s: String?, max: Int): String =
    (s ?: "").filter { !it.isISOControl() }.trim().take(max)

/**
 * Extracts only values actually present in the scanned QR.
 * Supported payment format: upi://pay?pa=UPI_ID&pn=Name&am=10.00&tn=Note
 * This app remains a local simulation; scanning never initiates a real UPI transfer.
 */
fun parseQr(raw: String): Payee {
    val text = clean(raw, MAX_QR_LEN)
    val uri = runCatching { Uri.parse(text) }.getOrNull()
    val isUpi = uri != null &&
        uri.scheme.equals("upi", ignoreCase = true) &&
        uri.host.equals("pay", ignoreCase = true)

    if (isUpi && uri != null) {
        val pa = clean(uri.getQueryParameter("pa"), 100)
        val pn = clean(uri.getQueryParameter("pn"), 100)
        val tn = clean(uri.getQueryParameter("tn"), 100)
        val amount = uri.getQueryParameter("am")
            ?.trim()
            ?.let { value ->
                runCatching {
                    BigDecimal(value)
                        .setScale(2, RoundingMode.DOWN)
                        .movePointRight(2)
                        .longValueExact()
                }.getOrNull()
            }

        val validAmount = amount?.takeIf {
            it > 0L && it <= DemoProvider.MAX_PER_TXN_PAISE
        }

        return Payee(
            name = pn.ifBlank { pa.ifBlank { "Unknown payee" } },
            upiId = pa.ifBlank { "UPI ID not present in QR" },
            amountPaise = validAmount,
            note = tn,
            isUpiQr = pa.isNotBlank(),
            rawText = text
        )
    }

    return Payee(
        name = if (text.length > 40) text.take(40) + "..." else text.ifBlank { "Unknown QR" },
        upiId = "Not a UPI QR",
        isUpiQr = false,
        rawText = text
    )
}
