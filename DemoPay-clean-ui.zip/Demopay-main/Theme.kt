package com.demopay.app

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val DemoGreen = Color(0xFF1B8A3C)
val DemoBlue = Color(0xFF2457E6)
val DemoBlueDark = Color(0xFF0F2E8A)

private val LightColors = lightColorScheme(
    primary = DemoBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EBFF),
    onPrimaryContainer = Color(0xFF0F2E8A),
    error = Color(0xFFD93025),
    background = Color(0xFFF4F6FB),
    onBackground = Color(0xFF14171F),
    surface = Color.White,
    onSurface = Color(0xFF14171F),
    surfaceVariant = Color(0xFFE9EDF6),
    onSurfaceVariant = Color(0xFF5A6275)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FB0FF),
    onPrimary = Color(0xFF0A1F5C),
    primaryContainer = Color(0xFF1B2E66),
    onPrimaryContainer = Color(0xFFD6E1FF),
    error = Color(0xFFFF8A80),
    background = Color(0xFF0F131C),
    onBackground = Color(0xFFE6E8EE),
    surface = Color(0xFF181D29),
    onSurface = Color(0xFFE6E8EE),
    surfaceVariant = Color(0xFF232A3A),
    onSurfaceVariant = Color(0xFFA5ADC2)
)

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF8FB0FF),
    onPrimary = Color(0xFF0A1F5C),
    primaryContainer = Color(0xFF111C40),
    onPrimaryContainer = Color(0xFFD6E1FF),
    error = Color(0xFFFF8A80),
    background = Color.Black,
    onBackground = Color(0xFFEDEEF1),
    surface = Color(0xFF0B0D12),
    onSurface = Color(0xFFEDEEF1),
    surfaceVariant = Color(0xFF141824),
    onSurfaceVariant = Color(0xFF9AA2B5)
)

@Composable
fun DemoPayTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val scheme = when (mode) {
        ThemeMode.LIGHT -> LightColors
        ThemeMode.DARK -> DarkColors
        ThemeMode.AMOLED -> AmoledColors
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = mode == ThemeMode.LIGHT
            controller.isAppearanceLightNavigationBars = mode == ThemeMode.LIGHT
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
